public class TestFile{
	public int void test(String[] args){
		System.out.println("Test2");
	}
}
